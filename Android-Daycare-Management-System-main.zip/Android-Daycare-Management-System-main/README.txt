Before running the application, remember to perform the following tasks to ensure the application is executed successfully:
1) Clean Project
2) Sync Project with Gradle Files
3) Rebuild Project